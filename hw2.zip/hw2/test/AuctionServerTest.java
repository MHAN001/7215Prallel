import org.junit.Test;

//Test?
public class AuctionServerTest {
    @Test
    private void testSubmit(){
        AuctionServer server = AuctionServer.getInstance();
        String[] args = {};
        Simulation.main(args);


    }
}
